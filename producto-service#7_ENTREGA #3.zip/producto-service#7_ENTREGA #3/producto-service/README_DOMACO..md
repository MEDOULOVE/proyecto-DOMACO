# DOMACO - Sistema de Gestión de Productos y Ventas

## Descripción

DOMACO es un sistema desarrollado con arquitectura de microservicios utilizando Spring Boot.

El proyecto permite administrar productos y registrar ventas mediante comunicación entre microservicios utilizando Feign Client.

---

## Acceso al Sistema

Usuario: admin

Contraseña: 1234

El login fue implementado en frontend para control básico de acceso al sistema.

---

## Integrante

- Medlin Dolcin

---

## Tecnologías Utilizadas

- Java 17
- Spring Boot
- Spring Data JPA
- Hibernate
- MySQL (Laragon)
- OpenFeign
- Spring Cloud Gateway
- Swagger / OpenAPI
- JUnit 5
- Mockito
- Maven
- Bootstrap
- HTML
- JavaScript

---

## Microservicios Implementados

### producto-service (Puerto 8083)

Funciones:

- Registrar productos
- Listar productos
- Actualizar productos
- Eliminar productos
- Buscar productos por código

### venta-service (Puerto 8081)

Funciones:

- Registrar ventas
- Listar ventas
- Eliminar ventas
- Consumir información de productos mediante Feign Client

### gateway-service (Puerto 8080)

Funciones:

- Centralizar el acceso a los microservicios
- Gestionar rutas de acceso
- Redireccionar solicitudes a producto-service y venta-service

---

## API Gateway

Rutas configuradas:

- http://localhost:8080/productos
- http://localhost:8080/ventas

---

## Swagger / OpenAPI

### Producto Service

http://localhost:8083/swagger-ui/index.html

### Venta Service

http://localhost:8081/swagger-ui/index.html

---

## Pruebas Unitarias

Implementadas utilizando:

- JUnit 5
- Mockito

### Producto Service

- guardarProductoCorrectamente()
- guardarProductoCodigoDuplicado()
- guardarProductoStockInvalido()

### Venta Service

- guardarVentaCorrectamente()
- guardarVentaSinStock()
- guardarVentaProductoNoEncontrado()

---

## Funcionalidades Implementadas

- CRUD de Productos
- CRUD de Ventas
- DTOs
- Validaciones con Bean Validation
- Manejo global de excepciones
- Comunicación entre microservicios
- Feign Client
- API Gateway
- Swagger/OpenAPI
- Pruebas Unitarias
- Configuración YAML
- Logs con SLF4J
- Persistencia con JPA e Hibernate

---

## Ejecución Local

1. Iniciar Laragon.
2. Crear las bases de datos necesarias.
3. Ejecutar producto-service.
4. Ejecutar venta-service.
5. Ejecutar gateway-service.
6. Abrir Swagger o consumir los endpoints mediante Postman.
7. Acceder al frontend.

---

## Puertos Utilizados

- Gateway Service → 8080
- Producto Service → 8083
- Venta Service → 8081

---

## Arquitectura

Cliente
↓
API Gateway (8080)
↓
Producto Service (8083)

Cliente
↓
API Gateway (8080)
↓
Venta Service (8081)

## Eureka Server

Puerto: 8761

Funciones:

- Registro de microservicios
- Descubrimiento de servicios
- Monitoreo de instancias activas
- 
- ## HATEOAS

Endpoint implementado:

http://localhost:8083/productos/{id}/hateoas

Permite incorporar enlaces de navegación REST dentro de la respuesta.

Links implementados:

- self
- todos-los-productos

## DataFaker

Se implementó DataFaker para generar datos ficticios utilizados en pruebas y demostraciones.

Datos generados:

- Nombre de producto
- Marca
- Precio

## Docker

Se implementaron Dockerfiles para los microservicios:

- producto-service
- venta-service

Imagen utilizada:

eclipse-temurin:17-jdk

Objetivo:

Permitir la ejecución de los microservicios dentro de contenedores Docker.