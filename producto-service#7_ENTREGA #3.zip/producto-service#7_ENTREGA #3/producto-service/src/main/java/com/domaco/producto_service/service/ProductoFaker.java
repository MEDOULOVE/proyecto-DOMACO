package com.domaco.producto_service.service;



import net.datafaker.Faker;

public class ProductoFaker {

    public static void main(String[] args) {

        Faker faker = new Faker();

        for (int i = 1; i <= 5; i++) {

            System.out.println(
                    "Producto: "
                            + faker.commerce().productName());

            System.out.println(
                    "Marca: "
                            + faker.company().name());

            System.out.println(
                    "Precio: "
                            + faker.number()
                            .numberBetween(1000, 50000));

            System.out.println("----------------------");
        }
    }
}