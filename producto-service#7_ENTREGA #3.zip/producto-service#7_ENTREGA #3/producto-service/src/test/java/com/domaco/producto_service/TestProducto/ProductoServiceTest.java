package com.domaco.producto_service.TestProducto;

import com.domaco.producto_service.model.Producto;
import com.domaco.producto_service.repository.ProductoRepository;
import com.domaco.producto_service.service.ProductoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    @Test
    void guardarProductoCorrectamente() {

        Producto producto = new Producto();
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(10);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL123");

        when(productoRepository.existsByCodigoProducto("TAL123"))
                .thenReturn(false);

        when(productoRepository.save(any(Producto.class)))
                .thenReturn(producto);

        Producto resultado = productoService.guardarProducto(producto);

        assertNotNull(resultado);
        assertEquals("Taladro", resultado.getNombre());

        verify(productoRepository).save(producto);

        System.out.println("\n\n✓ Test guardarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void guardarProductoCodigoDuplicado() {

        Producto producto = new Producto();
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(10);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL123");

        when(productoRepository.existsByCodigoProducto("TAL123"))
                .thenReturn(true);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> productoService.guardarProducto(producto));

        assertEquals("Ya existe un producto con este código", exception.getMessage());

        System.out.println("\n\n✓ Test guardarProductoCodigoDuplicado ejecutado correctamente");
    }

    @Test
    void guardarProductoStockInvalido() {

        Producto producto = new Producto();
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(0);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL123");

        when(productoRepository.existsByCodigoProducto("TAL123"))
                .thenReturn(false);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> productoService.guardarProducto(producto));

        assertEquals("El stock debe ser mayor a 0", exception.getMessage());

        System.out.println("\n\n✓ Test guardarProductoStockInvalido ejecutado correctamente");
    }

    @Test
    void listarProductosCorrectamente() {

        Producto p1 = new Producto();
        p1.setId(1L);
        p1.setNombre("Taladro");
        p1.setPrecio(45990.0);
        p1.setStock(10);
        p1.setCategoria("Herramientas");
        p1.setMarca("Bosch");
        p1.setCodigoProducto("TAL123");

        Producto p2 = new Producto();
        p2.setId(2L);
        p2.setNombre("Martillo");
        p2.setPrecio(15990.0);
        p2.setStock(20);
        p2.setCategoria("Herramientas");
        p2.setMarca("Stanley");
        p2.setCodigoProducto("MAR002");

        when(productoRepository.findAll())
                .thenReturn(List.of(p1, p2));

        List<Producto> resultado = productoService.listarProductos();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("Taladro", resultado.get(0).getNombre());

        verify(productoRepository).findAll();

        System.out.println("\n\n✓ Test listarProductosCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerProductoPorIdCorrectamente() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(10);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL123");

        when(productoRepository.findById(1L))
                .thenReturn(Optional.of(producto));

        Producto resultado = productoService.obtenerProductoPorId(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Taladro", resultado.getNombre());

        verify(productoRepository).findById(1L);

        System.out.println("\n\n✓ Test obtenerProductoPorIdCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerProductoPorCodigoCorrectamente() {

        Producto producto = new Producto();
        producto.setId(2L);
        producto.setNombre("Martillo");
        producto.setPrecio(15990.0);
        producto.setStock(20);
        producto.setCategoria("Herramientas");
        producto.setMarca("Stanley");
        producto.setCodigoProducto("MAR002");

        when(productoRepository.findByCodigoProducto("MAR002"))
                .thenReturn(Optional.of(producto));

        Producto resultado = productoService.obtenerProductoPorCodigo("MAR002");

        assertNotNull(resultado);
        assertEquals("Martillo", resultado.getNombre());
        assertEquals("MAR002", resultado.getCodigoProducto());

        verify(productoRepository).findByCodigoProducto("MAR002");

        System.out.println("\n\n✓ Test obtenerProductoPorCodigoCorrectamente ejecutado correctamente");
    }

    @Test
    void eliminarProductoCorrectamente() {

        Producto producto = new Producto();
        producto.setId(3L);
        producto.setNombre("Cemento");
        producto.setPrecio(5990.0);
        producto.setStock(30);
        producto.setCategoria("Construcción");
        producto.setMarca("Melón");
        producto.setCodigoProducto("CEM003");

        when(productoRepository.findById(3L))
                .thenReturn(Optional.of(producto));

        doNothing().when(productoRepository).delete(producto);

        assertDoesNotThrow(() -> productoService.eliminarProducto(3L));

        verify(productoRepository).findById(3L);
        verify(productoRepository).delete(producto);

        System.out.println("\n\n✓ Test eliminarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarProductoCorrectamente() {

        Producto existente = new Producto();
        existente.setId(1L);
        existente.setNombre("Taladro viejo");
        existente.setPrecio(30000.0);
        existente.setStock(5);
        existente.setCategoria("Herramientas");
        existente.setMarca("Bosch");
        existente.setCodigoProducto("TAL123");

        Producto actualizado = new Producto();
        actualizado.setNombre("Taladro nuevo");
        actualizado.setPrecio(45990.0);
        actualizado.setStock(15);
        actualizado.setCategoria("Herramientas");
        actualizado.setMarca("Bosch Pro");
        actualizado.setCodigoProducto("TAL123");

        when(productoRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(productoRepository.save(any(Producto.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Producto resultado = productoService.actualizarProducto(1L, actualizado);

        assertNotNull(resultado);
        assertEquals("Taladro nuevo", resultado.getNombre());
        assertEquals(45990.0, resultado.getPrecio());
        assertEquals(15, resultado.getStock());

        verify(productoRepository).findById(1L);
        verify(productoRepository).save(existente);

        System.out.println("\n\n✓ Test actualizarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarProductoNoEncontrado() {

        Producto actualizado = new Producto();
        actualizado.setNombre("Taladro nuevo");
        actualizado.setPrecio(45990.0);
        actualizado.setStock(15);
        actualizado.setCategoria("Herramientas");
        actualizado.setMarca("Bosch");
        actualizado.setCodigoProducto("TAL123");

        when(productoRepository.findById(99L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> productoService.actualizarProducto(99L, actualizado)
        );

        assertEquals("Producto no encontrado", exception.getMessage());

        verify(productoRepository).findById(99L);

        System.out.println("\n\n✓ Test actualizarProductoNoEncontrado ejecutado correctamente");
    }
}