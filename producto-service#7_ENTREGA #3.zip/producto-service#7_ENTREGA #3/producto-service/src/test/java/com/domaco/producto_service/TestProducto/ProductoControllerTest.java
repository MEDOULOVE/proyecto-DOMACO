package com.domaco.producto_service.TestProducto;

import com.domaco.producto_service.controller.ProductoController;
import com.domaco.producto_service.dto.ProductoDTO;
import com.domaco.producto_service.model.Producto;
import com.domaco.producto_service.service.ProductoService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductoControllerTest {

    @Mock
    private ProductoService productoService;

    @InjectMocks
    private ProductoController productoController;

    @Test
    void listarProductosCorrectamente() {

        Producto p1 = new Producto();
        p1.setId(1L);
        p1.setNombre("Taladro");
        p1.setPrecio(45990.0);
        p1.setStock(10);
        p1.setCategoria("Herramientas");
        p1.setMarca("Bosch");
        p1.setCodigoProducto("TAL-001");

        Producto p2 = new Producto();
        p2.setId(2L);
        p2.setNombre("Martillo");
        p2.setPrecio(15990.0);
        p2.setStock(20);
        p2.setCategoria("Herramientas");
        p2.setMarca("Stanley");
        p2.setCodigoProducto("MAR-002");

        when(productoService.listarProductos())
                .thenReturn(List.of(p1, p2));

        ResponseEntity<?> response = productoController.listarProductos();

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());

        List<?> productos = (List<?>) response.getBody();
        assertEquals(2, productos.size());

        System.out.println("\n\n✓ Test controller listarProductosCorrectamente ejecutado correctamente");
    }

    @Test
    void listarProductosSinRegistros() {

        when(productoService.listarProductos())
                .thenReturn(List.of());

        ResponseEntity<?> response = productoController.listarProductos();

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("No hay productos registrados", response.getBody());

        System.out.println("\n\n✓ Test controller listarProductosSinRegistros ejecutado correctamente");
    }

    @Test
    void guardarProductoCorrectamente() {

        ProductoDTO dto = new ProductoDTO();
        dto.setNombre("Taladro");
        dto.setPrecio(45990.0);
        dto.setStock(10);
        dto.setCategoria("Herramientas");
        dto.setMarca("Bosch");
        dto.setCodigoProducto("TAL-001");

        when(productoService.guardarProducto(any(Producto.class)))
                .thenReturn(new Producto());

        ResponseEntity<String> response = productoController.guardarProducto(dto);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Producto agregado correctamente", response.getBody());

        verify(productoService, times(1)).guardarProducto(any(Producto.class));

        System.out.println("\n\n✓ Test controller guardarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void guardarListaCorrectamente() {

        Producto p1 = new Producto();
        p1.setNombre("Taladro");
        p1.setPrecio(45990.0);
        p1.setStock(10);
        p1.setCategoria("Herramientas");
        p1.setMarca("Bosch");
        p1.setCodigoProducto("TAL-001");

        Producto p2 = new Producto();
        p2.setNombre("Martillo");
        p2.setPrecio(15990.0);
        p2.setStock(20);
        p2.setCategoria("Herramientas");
        p2.setMarca("Stanley");
        p2.setCodigoProducto("MAR-002");

        when(productoService.guardarProducto(any(Producto.class)))
                .thenReturn(new Producto());

        ResponseEntity<String> response =
                productoController.guardarLista(List.of(p1, p2));

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Productos agregados correctamente", response.getBody());

        verify(productoService, times(2)).guardarProducto(any(Producto.class));

        System.out.println("\n\n✓ Test controller guardarListaCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarProductoCorrectamente() {

        Producto entrada = new Producto();
        entrada.setNombre("Taladro Pro");
        entrada.setPrecio(55990.0);
        entrada.setStock(15);
        entrada.setCategoria("Herramientas");
        entrada.setMarca("Bosch");
        entrada.setCodigoProducto("TAL-001");

        Producto actualizado = new Producto();
        actualizado.setId(1L);
        actualizado.setNombre("Taladro Pro");
        actualizado.setPrecio(55990.0);
        actualizado.setStock(15);
        actualizado.setCategoria("Herramientas");
        actualizado.setMarca("Bosch");
        actualizado.setCodigoProducto("TAL-001");

        when(productoService.actualizarProducto(1L, entrada))
                .thenReturn(actualizado);

        ResponseEntity<Producto> response =
                productoController.actualizarProducto(1L, entrada);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertEquals("Taladro Pro", response.getBody().getNombre());

        System.out.println("\n\n✓ Test controller actualizarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerPorCodigoCorrectamente() {

        Producto producto = new Producto();
        producto.setId(2L);
        producto.setNombre("Martillo");
        producto.setPrecio(15990.0);
        producto.setStock(20);
        producto.setCategoria("Herramientas");
        producto.setMarca("Stanley");
        producto.setCodigoProducto("MAR-002");

        when(productoService.obtenerProductoPorCodigo("MAR-002"))
                .thenReturn(producto);

        ResponseEntity<?> response =
                productoController.obtenerPorCodigo("MAR-002");

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals(producto, response.getBody());

        System.out.println("\n\n✓ Test controller obtenerPorCodigoCorrectamente ejecutado correctamente");
    }

    @Test
    void eliminarProductoCorrectamente() {

        doNothing().when(productoService).eliminarProducto(1L);

        ResponseEntity<String> response = productoController.eliminarProducto(1L);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Producto eliminado correctamente", response.getBody());

        verify(productoService, times(1)).eliminarProducto(1L);

        System.out.println("\n\n✓ Test controller eliminarProductoCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerProductoPorIdCorrectamente() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(10);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL-001");

        when(productoService.obtenerProductoPorId(1L))
                .thenReturn(producto);

        Producto resultado = productoController.obtenerProductoPorId(1L);

        assertNotNull(resultado);
        assertEquals("Taladro", resultado.getNombre());
        assertEquals("TAL-001", resultado.getCodigoProducto());

        System.out.println("\n\n✓ Test controller obtenerProductoPorIdCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerProductoHateoasCorrectamente() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Taladro");
        producto.setPrecio(45990.0);
        producto.setStock(10);
        producto.setCategoria("Herramientas");
        producto.setMarca("Bosch");
        producto.setCodigoProducto("TAL-001");

        when(productoService.obtenerProductoPorId(1L))
                .thenReturn(producto);

        EntityModel<Producto> response =
                productoController.obtenerProductoHateoas(1L);

        assertNotNull(response);
        assertNotNull(response.getContent());
        assertEquals("Taladro", response.getContent().getNombre());
        assertTrue(response.getLinks().hasLink("self"));
        assertTrue(response.getLinks().hasLink("todos-los-productos"));

        System.out.println("\n\n✓ Test controller obtenerProductoHateoasCorrectamente ejecutado correctamente");
    }


}