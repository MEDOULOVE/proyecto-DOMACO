package com.domaco.producto_service.TestProducto;

import com.domaco.producto_service.exception.GlobalExceptionHandler;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler =
            new GlobalExceptionHandler();

    @Test
    void manejarRuntimeExceptionCorrectamente() {

        RuntimeException ex =
                new RuntimeException("Producto no encontrado");

        ResponseEntity<String> response =
                handler.manejarRuntimeException(ex);

        assertNotNull(response);
        assertEquals(404, response.getStatusCode().value());
        assertEquals("Producto no encontrado", response.getBody());

        System.out.println(
                "\n\n✓ Test exception manejarRuntimeExceptionCorrectamente ejecutado correctamente");
    }

    @Test
    void manejarValidacionesCorrectamente() {

        MethodArgumentNotValidException ex =
                mock(MethodArgumentNotValidException.class);

        BeanPropertyBindingResult bindingResult =
                new BeanPropertyBindingResult(new Object(), "productoDTO");

        bindingResult.addError(
                new FieldError(
                        "productoDTO",
                        "nombre",
                        "El nombre es obligatorio"
                )
        );

        bindingResult.addError(
                new FieldError(
                        "productoDTO",
                        "precio",
                        "El precio debe ser mayor a 0"
                )
        );

        when(ex.getBindingResult()).thenReturn(bindingResult);

        ResponseEntity<Map<String, String>> response =
                handler.manejarValidaciones(ex);

        assertNotNull(response);
        assertEquals(400, response.getStatusCode().value());
        assertNotNull(response.getBody());

        Map<String, String> errores = response.getBody();

        assertEquals("El nombre es obligatorio", errores.get("nombre"));
        assertEquals("El precio debe ser mayor a 0", errores.get("precio"));
        assertEquals(2, errores.size());

        System.out.println(
                "\n\n✓ Test exception manejarValidacionesCorrectamente ejecutado correctamente");
    }
}