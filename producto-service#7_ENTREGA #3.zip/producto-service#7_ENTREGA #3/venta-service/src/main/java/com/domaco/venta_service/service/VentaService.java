package com.domaco.venta_service.service;

import com.domaco.venta_service.client.ProductoClient;
import com.domaco.venta_service.dto.ProductoDTO;
import com.domaco.venta_service.model.Venta;
import com.domaco.venta_service.repository.VentaRepository;

import org.springframework.stereotype.Service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class VentaService {

    private static final Logger logger =
            LoggerFactory.getLogger(VentaService.class);

    private final VentaRepository ventaRepository;
    private final ProductoClient productoClient;

    public VentaService(
            VentaRepository ventaRepository,
            ProductoClient productoClient) {

        this.ventaRepository = ventaRepository;
        this.productoClient = productoClient;
    }

    public List<Venta> listarVentas() {

        logger.info("Listando ventas");

        return ventaRepository.findAll();
    }


    public Venta guardarVenta(Venta venta) {

        logger.info(
                "Registrando venta para cliente: {}",
                venta.getCliente());

        ProductoDTO producto;

        try {

            logger.info(
                    "Código recibido: {}",
                    venta.getProductoId());

            producto =
                    productoClient.obtenerProductoPorCodigo(
                            venta.getProductoId());

            logger.info(
                    "Producto encontrado: {}",
                    producto);

        }catch (Exception e) {

            logger.error(
                    "Error al buscar producto: {}",
                    e.getMessage());

            throw new RuntimeException(
                    "Producto no encontrado");
        }

        if (producto == null) {

            throw new RuntimeException(
                    "Producto no encontrado");
        }

        if (producto.getStock() <= 0) {

            throw new RuntimeException(
                    "No hay stock disponible");
        }

        if (venta.getCantidad() > producto.getStock()) {

            throw new RuntimeException(
                    "Stock insuficiente. Disponible: "
                            + producto.getStock());
        }

        // Descontar stock
        producto.setStock(
                producto.getStock()
                        - venta.getCantidad());

// Actualizar stock en producto-service
        productoClient.actualizarProducto(
                producto.getId(),
                producto);

        venta.setProductoId(
                producto.getCodigoProducto());

        venta.setProductoNombre(
                producto.getNombre());

        Double total =
                producto.getPrecio()
                        * venta.getCantidad();

        venta.setTotal(total);

        return ventaRepository.save(venta);
    }

    public Venta actualizarVenta(
            Long id,
            Venta ventaActualizada) {

        Venta venta =
                ventaRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Venta no encontrada"));

        venta.setCliente(
                ventaActualizada.getCliente());

        venta.setCantidad(
                ventaActualizada.getCantidad());

        return ventaRepository.save(
                venta);
    }

    public void eliminarVenta(Long id) {

        Venta venta =
                ventaRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Venta no encontrada"));

        ventaRepository.delete(venta);
    }

    public Venta obtenerVentaPorId(Long id) {

        return ventaRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Venta no encontrada"));
    }
}