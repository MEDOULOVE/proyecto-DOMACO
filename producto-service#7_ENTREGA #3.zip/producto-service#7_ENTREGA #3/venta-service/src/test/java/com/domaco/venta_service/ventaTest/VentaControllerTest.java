package com.domaco.venta_service.TestVenta;

import com.domaco.venta_service.controller.VentaController;
import com.domaco.venta_service.model.Venta;
import com.domaco.venta_service.service.VentaService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VentaControllerTest {

    @Mock
    private VentaService ventaService;

    @InjectMocks
    private VentaController ventaController;

    @Test
    void listarVentasCorrectamente() {

        Venta v1 = new Venta();
        v1.setId(1L);
        v1.setCliente("Juan Pérez");
        v1.setProductoId("MAR-002");
        v1.setProductoNombre("Martillo");
        v1.setCantidad(2);
        v1.setTotal(31980.0);

        Venta v2 = new Venta();
        v2.setId(2L);
        v2.setCliente("María López");
        v2.setProductoId("TAL-001");
        v2.setProductoNombre("Taladro");
        v2.setCantidad(1);
        v2.setTotal(45990.0);

        when(ventaService.listarVentas())
                .thenReturn(List.of(v1, v2));

        ResponseEntity<?> response = ventaController.listarVentas();

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertTrue(response.getBody() instanceof List);

        List<?> ventas = (List<?>) response.getBody();
        assertEquals(2, ventas.size());

        System.out.println("\n\n✓ Test controller listarVentasCorrectamente ejecutado correctamente");
    }

    @Test
    void listarVentasVacio() {

        when(ventaService.listarVentas())
                .thenReturn(List.of());

        ResponseEntity<?> response = ventaController.listarVentas();

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("No hay ventas registradas", response.getBody());

        System.out.println("\n\n✓ Test controller listarVentasVacio ejecutado correctamente");
    }

    @Test
    void guardarVentaCorrectamente() {

        Venta venta = new Venta();
        venta.setCliente("Juan Pérez");
        venta.setProductoId("MAR-002");
        venta.setCantidad(2);

        when(ventaService.guardarVenta(any(Venta.class)))
                .thenReturn(venta);

        ResponseEntity<String> response = ventaController.guardarVenta(venta);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Venta registrada correctamente", response.getBody());

        verify(ventaService).guardarVenta(venta);

        System.out.println("\n\n✓ Test controller guardarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarVentaCorrectamente() {

        Venta venta = new Venta();
        venta.setCliente("Juan Pérez");
        venta.setProductoId("MAR-002");
        venta.setCantidad(3);

        when(ventaService.actualizarVenta(eq(1L), any(Venta.class)))
                .thenReturn(venta);

        ResponseEntity<String> response = ventaController.actualizarVenta(1L, venta);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Venta actualizada correctamente", response.getBody());

        verify(ventaService).actualizarVenta(1L, venta);

        System.out.println("\n\n✓ Test controller actualizarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void eliminarVentaCorrectamente() {

        doNothing().when(ventaService).eliminarVenta(1L);

        ResponseEntity<String> response = ventaController.eliminarVenta(1L);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("Venta eliminada correctamente", response.getBody());

        verify(ventaService).eliminarVenta(1L);

        System.out.println("\n\n✓ Test controller eliminarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerVentaPorIdCorrectamente() {

        Venta venta = new Venta();
        venta.setId(1L);
        venta.setCliente("Juan Pérez");
        venta.setProductoId("MAR-002");
        venta.setProductoNombre("Martillo");
        venta.setCantidad(2);
        venta.setTotal(31980.0);

        when(ventaService.obtenerVentaPorId(1L))
                .thenReturn(venta);

        ResponseEntity<?> response = ventaController.obtenerVentaPorId(1L);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertEquals(venta, response.getBody());

        System.out.println("\n\n✓ Test controller obtenerVentaPorIdCorrectamente ejecutado correctamente");
    }
}