package com.domaco.venta_service.ventaTest;

import com.domaco.venta_service.client.ProductoClient;
import com.domaco.venta_service.dto.ProductoDTO;
import com.domaco.venta_service.model.Venta;
import com.domaco.venta_service.repository.VentaRepository;
import com.domaco.venta_service.service.VentaService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @Mock
    private ProductoClient productoClient;

    @InjectMocks
    private VentaService ventaService;

    @Test
    void guardarVentaCorrectamente() {

        Venta venta = new Venta();
        venta.setCliente("Maria");
        venta.setProductoId("MAR-002");
        venta.setCantidad(2);

        ProductoDTO producto = new ProductoDTO();
        producto.setId(2L);
        producto.setNombre("Martillo");
        producto.setPrecio(15990.0);
        producto.setStock(20);
        producto.setCodigoProducto("MAR-002");

        when(productoClient.obtenerProductoPorCodigo("MAR-002"))
                .thenReturn(producto);

        when(ventaRepository.save(any(Venta.class)))
                .thenAnswer(i -> i.getArgument(0));

        Venta resultado = ventaService.guardarVenta(venta);

        assertNotNull(resultado);
        assertEquals("Martillo", resultado.getProductoNombre());
        assertEquals("MAR-002", resultado.getProductoId());
        assertEquals(31980.0, resultado.getTotal());

        verify(productoClient).actualizarProducto(eq(2L), any(ProductoDTO.class));
        verify(ventaRepository).save(any(Venta.class));

        System.out.println("\n\n✓ Test guardarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void guardarVentaProductoNoEncontradoPorExcepcion() {

        Venta venta = new Venta();
        venta.setCliente("Maria");
        venta.setProductoId("XXX-999");
        venta.setCantidad(1);

        when(productoClient.obtenerProductoPorCodigo("XXX-999"))
                .thenThrow(new RuntimeException());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.guardarVenta(venta));

        assertEquals("Producto no encontrado", exception.getMessage());

        System.out.println("\n\n✓ Test guardarVentaProductoNoEncontradoPorExcepcion ejecutado correctamente");
    }

    @Test
    void guardarVentaProductoNull() {

        Venta venta = new Venta();
        venta.setCliente("Maria");
        venta.setProductoId("XXX-999");
        venta.setCantidad(1);

        when(productoClient.obtenerProductoPorCodigo("XXX-999"))
                .thenReturn(null);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.guardarVenta(venta));

        assertEquals("Producto no encontrado", exception.getMessage());

        System.out.println("\n\n✓ Test guardarVentaProductoNull ejecutado correctamente");
    }

    @Test
    void guardarVentaSinStockDisponible() {

        Venta venta = new Venta();
        venta.setCliente("Maria");
        venta.setProductoId("MAR-002");
        venta.setCantidad(1);

        ProductoDTO producto = new ProductoDTO();
        producto.setId(2L);
        producto.setNombre("Martillo");
        producto.setPrecio(15990.0);
        producto.setStock(0);
        producto.setCodigoProducto("MAR-002");

        when(productoClient.obtenerProductoPorCodigo("MAR-002"))
                .thenReturn(producto);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.guardarVenta(venta));

        assertEquals("No hay stock disponible", exception.getMessage());

        System.out.println("\n\n✓ Test guardarVentaSinStockDisponible ejecutado correctamente");
    }

    @Test
    void guardarVentaStockInsuficiente() {

        Venta venta = new Venta();
        venta.setCliente("Maria");
        venta.setProductoId("MAR-002");
        venta.setCantidad(50);

        ProductoDTO producto = new ProductoDTO();
        producto.setId(2L);
        producto.setNombre("Martillo");
        producto.setPrecio(15990.0);
        producto.setStock(20);
        producto.setCodigoProducto("MAR-002");

        when(productoClient.obtenerProductoPorCodigo("MAR-002"))
                .thenReturn(producto);

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.guardarVenta(venta));

        assertEquals("Stock insuficiente. Disponible: 20", exception.getMessage());

        System.out.println("\n\n✓ Test guardarVentaStockInsuficiente ejecutado correctamente");
    }

    @Test
    void listarVentasCorrectamente() {

        Venta v1 = new Venta();
        v1.setId(1L);
        v1.setCliente("Juan");
        v1.setProductoId("MAR-002");
        v1.setProductoNombre("Martillo");
        v1.setCantidad(2);
        v1.setTotal(31980.0);

        Venta v2 = new Venta();
        v2.setId(2L);
        v2.setCliente("Maria");
        v2.setProductoId("TAL-001");
        v2.setProductoNombre("Taladro");
        v2.setCantidad(1);
        v2.setTotal(45990.0);

        when(ventaRepository.findAll())
                .thenReturn(List.of(v1, v2));

        List<Venta> resultado = ventaService.listarVentas();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("Juan", resultado.get(0).getCliente());

        verify(ventaRepository).findAll();

        System.out.println("\n\n✓ Test listarVentasCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarVentaCorrectamente() {

        Venta existente = new Venta();
        existente.setId(1L);
        existente.setCliente("Juan");
        existente.setProductoId("MAR-002");
        existente.setProductoNombre("Martillo");
        existente.setCantidad(2);
        existente.setTotal(31980.0);

        Venta actualizada = new Venta();
        actualizada.setCliente("Pedro");
        actualizada.setCantidad(5);

        when(ventaRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(ventaRepository.save(any(Venta.class)))
                .thenAnswer(i -> i.getArgument(0));

        Venta resultado = ventaService.actualizarVenta(1L, actualizada);

        assertNotNull(resultado);
        assertEquals("Pedro", resultado.getCliente());
        assertEquals(5, resultado.getCantidad());

        verify(ventaRepository).findById(1L);
        verify(ventaRepository).save(existente);

        System.out.println("\n\n✓ Test actualizarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void actualizarVentaNoEncontrada() {

        Venta actualizada = new Venta();
        actualizada.setCliente("Pedro");
        actualizada.setCantidad(5);

        when(ventaRepository.findById(99L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.actualizarVenta(99L, actualizada));

        assertEquals("Venta no encontrada", exception.getMessage());

        verify(ventaRepository).findById(99L);

        System.out.println("\n\n✓ Test actualizarVentaNoEncontrada ejecutado correctamente");
    }

    @Test
    void eliminarVentaCorrectamente() {

        Venta venta = new Venta();
        venta.setId(1L);
        venta.setCliente("Juan");
        venta.setProductoId("MAR-002");
        venta.setCantidad(2);

        when(ventaRepository.findById(1L))
                .thenReturn(Optional.of(venta));

        doNothing().when(ventaRepository).delete(venta);

        assertDoesNotThrow(() -> ventaService.eliminarVenta(1L));

        verify(ventaRepository).findById(1L);
        verify(ventaRepository).delete(venta);

        System.out.println("\n\n✓ Test eliminarVentaCorrectamente ejecutado correctamente");
    }

    @Test
    void eliminarVentaNoEncontrada() {

        when(ventaRepository.findById(99L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.eliminarVenta(99L));

        assertEquals("Venta no encontrada", exception.getMessage());

        verify(ventaRepository).findById(99L);

        System.out.println("\n\n✓ Test eliminarVentaNoEncontrada ejecutado correctamente");
    }

    @Test
    void obtenerVentaPorIdCorrectamente() {

        Venta venta = new Venta();
        venta.setId(1L);
        venta.setCliente("Juan");
        venta.setProductoId("MAR-002");
        venta.setProductoNombre("Martillo");
        venta.setCantidad(2);
        venta.setTotal(31980.0);

        when(ventaRepository.findById(1L))
                .thenReturn(Optional.of(venta));

        Venta resultado = ventaService.obtenerVentaPorId(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Juan", resultado.getCliente());

        verify(ventaRepository).findById(1L);

        System.out.println("\n\n✓ Test obtenerVentaPorIdCorrectamente ejecutado correctamente");
    }

    @Test
    void obtenerVentaPorIdNoEncontrada() {

        when(ventaRepository.findById(99L))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> ventaService.obtenerVentaPorId(99L));

        assertEquals("Venta no encontrada", exception.getMessage());

        verify(ventaRepository).findById(99L);

        System.out.println("\n\n✓ Test obtenerVentaPorIdNoEncontrada ejecutado correctamente");
    }
}