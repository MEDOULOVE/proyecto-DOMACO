package com.domaco.venta_service.TestVenta;

import com.domaco.venta_service.exception.GlobalExceptionHandler;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler =
            new GlobalExceptionHandler();

    @Test
    void manejarRuntimeExceptionCorrectamente() {

        RuntimeException ex =
                new RuntimeException("Stock insuficiente");

        ResponseEntity<String> response =
                handler.manejarRuntimeException(ex);

        assertNotNull(response);
        assertEquals(400, response.getStatusCode().value());
        assertEquals("Stock insuficiente", response.getBody());

        System.out.println("\n\n✓ Test exception manejarRuntimeExceptionCorrectamente ejecutado correctamente");
    }

    @Test
    void manejarExceptionCorrectamente() {

        Exception ex =
                new Exception("Error inesperado");

        ResponseEntity<String> response =
                handler.manejarException(ex);

        assertNotNull(response);
        assertEquals(500, response.getStatusCode().value());
        assertEquals("Error interno del servidor", response.getBody());

        System.out.println("\n\n✓ Test exception manejarExceptionCorrectamente ejecutado correctamente");
    }
}