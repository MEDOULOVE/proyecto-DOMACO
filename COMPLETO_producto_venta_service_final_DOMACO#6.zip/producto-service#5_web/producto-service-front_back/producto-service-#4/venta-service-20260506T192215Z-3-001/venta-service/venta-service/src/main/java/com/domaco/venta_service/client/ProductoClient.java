package com.domaco.venta_service.client;

import com.domaco.venta_service.dto.ProductoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "producto-service", url = "http://localhost:8083")
public interface ProductoClient {

    @GetMapping("/productos/{id}")
    ProductoDTO obtenerProductoPorId(@PathVariable Long id);

    @GetMapping("/productos/codigo/{codigo}")
    ProductoDTO obtenerProductoPorCodigo(
            @PathVariable String codigo);
}