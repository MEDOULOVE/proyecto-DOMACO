package com.domaco.venta_service.service;

import com.domaco.venta_service.client.ProductoClient;
import com.domaco.venta_service.dto.ProductoDTO;
import com.domaco.venta_service.model.Venta;
import com.domaco.venta_service.repository.VentaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentaService {

    private final VentaRepository ventaRepository;
    private final ProductoClient productoClient;

    public VentaService(VentaRepository ventaRepository,
                        ProductoClient productoClient) {

        this.ventaRepository = ventaRepository;
        this.productoClient = productoClient;
    }

    public List<Venta> listarVentas() {
        return ventaRepository.findAll();
    }

    public Venta guardarVenta(Venta venta) {

        ProductoDTO producto =
                productoClient.obtenerProductoPorId(venta.getProductoId());

        if (producto == null) {
            throw new RuntimeException("Producto no encontrado");
        }

        venta.setProductoNombre(producto.getNombre());

        Double total =
                producto.getPrecio() * venta.getCantidad();

        venta.setTotal(total);

        return ventaRepository.save(venta);
    }
}