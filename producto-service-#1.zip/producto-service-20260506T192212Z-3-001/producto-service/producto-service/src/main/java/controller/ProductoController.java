package com.domaco.producto_service.controller;
import com.domaco.producto_service.dto.ProductoDTO;
import jakarta.validation.Valid;
import com.domaco.producto_service.model.Producto;
import com.domaco.producto_service.service.ProductoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    public List<Producto> listarProductos() {
        return productoService.listarProductos();
    }

    @PostMapping
    public ResponseEntity<String> guardarProducto(@Valid @RequestBody ProductoDTO productoDTO) {

        Producto producto = new Producto();

        producto.setNombre(productoDTO.getNombre());
        producto.setPrecio(productoDTO.getPrecio());
        producto.setStock(productoDTO.getStock());

        productoService.guardarProducto(producto);

        return ResponseEntity.ok("Producto agregado correctamente");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> actualizarProducto(@PathVariable Long id,
                                                     @RequestBody Producto producto) {

        productoService.actualizarProducto(id, producto);

        return ResponseEntity.ok("Producto actualizado correctamente");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarProducto(@PathVariable Long id) {

        productoService.eliminarProducto(id);

        return ResponseEntity.ok("Producto eliminado correctamente");
    }

    @GetMapping("/{id}")
    public Producto obtenerProductoPorId(@PathVariable Long id) {

        return productoService.obtenerProductoPorId(id);
    }

}