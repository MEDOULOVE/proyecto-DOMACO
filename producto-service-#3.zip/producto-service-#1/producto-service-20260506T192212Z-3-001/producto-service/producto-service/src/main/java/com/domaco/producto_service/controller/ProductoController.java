package com.domaco.producto_service.controller;

import com.domaco.producto_service.dto.ProductoDTO;
import com.domaco.producto_service.model.Producto;
import com.domaco.producto_service.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    public ResponseEntity<?> listarProductos() {

        List<Producto> productos = productoService.listarProductos();

        if (productos.isEmpty()) {
            return ResponseEntity.ok("No hay productos registrados");
        }

        return ResponseEntity.ok(productos);
    }

    @PostMapping
    public ResponseEntity<String> guardarProducto(@Valid @RequestBody ProductoDTO productoDTO) {

        Producto producto = new Producto();

        producto.setNombre(productoDTO.getNombre());
        producto.setPrecio(productoDTO.getPrecio());
        producto.setStock(productoDTO.getStock());

        productoService.guardarProducto(producto);

        return ResponseEntity.ok("Producto agregado correctamente");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> actualizarProducto(@PathVariable Long id,
                                                     @RequestBody Producto producto) {

        productoService.actualizarProducto(id, producto);

        return ResponseEntity.ok("Producto actualizado correctamente");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarProducto(@PathVariable Long id) {

        productoService.eliminarProducto(id);

        return ResponseEntity.ok("Producto eliminado correctamente");
    }

    @GetMapping("/{id}")
    public Producto obtenerProductoPorId(@PathVariable Long id) {

        return productoService.obtenerProductoPorId(id);
    }
}