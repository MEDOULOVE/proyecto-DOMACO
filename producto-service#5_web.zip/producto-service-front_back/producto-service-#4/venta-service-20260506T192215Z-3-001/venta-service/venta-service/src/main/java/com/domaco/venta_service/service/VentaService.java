package com.domaco.venta_service.service;

import com.domaco.venta_service.client.ProductoClient;
import com.domaco.venta_service.dto.ProductoDTO;
import com.domaco.venta_service.model.Venta;
import com.domaco.venta_service.repository.VentaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class VentaService {

    private static final Logger logger =
            LoggerFactory.getLogger(VentaService.class);

    private final VentaRepository ventaRepository;
    private final ProductoClient productoClient;

    public VentaService(VentaRepository ventaRepository,
                        ProductoClient productoClient) {

        this.ventaRepository = ventaRepository;
        this.productoClient = productoClient;
    }

    public List<Venta> listarVentas() {

        logger.info("Listando ventas");

        return ventaRepository.findAll();
    }

    public Venta guardarVenta(Venta venta) {

        logger.info("Registrando venta para cliente: {}", venta.getCliente());

        ProductoDTO producto =
                productoClient.obtenerProductoPorId(venta.getProductoId());

        if (producto == null) {

            logger.error("Producto no encontrado");

            throw new RuntimeException("Producto no encontrado");
        }

        venta.setProductoNombre(producto.getNombre());

        Double total =
                producto.getPrecio() * venta.getCantidad();

        venta.setTotal(total);

        logger.info("Venta registrada correctamente");

        return ventaRepository.save(venta);
    }

    public Venta actualizarVenta(Long id, Venta ventaActualizada) {

        logger.info("Actualizando venta con ID: {}", id);

        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Venta no encontrada"));

        ProductoDTO producto =
                productoClient.obtenerProductoPorId(
                        ventaActualizada.getProductoId());

        venta.setCliente(ventaActualizada.getCliente());
        venta.setProductoId(producto.getId());
        venta.setProductoNombre(producto.getNombre());
        venta.setCantidad(ventaActualizada.getCantidad());

        Double total =
                producto.getPrecio() * ventaActualizada.getCantidad();

        venta.setTotal(total);

        logger.info("Venta actualizada correctamente");

        return ventaRepository.save(venta);
    }

    public void eliminarVenta(Long id) {

        logger.info("Eliminando venta con ID: {}", id);

        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Venta no encontrada"));

        ventaRepository.delete(venta);

        logger.info("Venta eliminada correctamente");
    }
    public Venta obtenerVentaPorId(Long id) {

        logger.info("Buscando venta con ID: {}", id);

        return ventaRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Venta no encontrada"));
    }
}