CREATE TABLE productos (
                           id BIGINT PRIMARY KEY AUTO_INCREMENT,
                           nombre VARCHAR(255) NOT NULL,
                           precio DOUBLE NOT NULL,
                           stock INT NOT NULL
);